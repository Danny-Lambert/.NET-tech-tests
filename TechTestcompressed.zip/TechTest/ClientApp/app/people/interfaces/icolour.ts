export interface IColour {
    id: number;
    name: string;
}
